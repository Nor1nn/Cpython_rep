from django.apps import AppConfig


class PagesAppConfig(AppConfig):

    name = 'pages'
