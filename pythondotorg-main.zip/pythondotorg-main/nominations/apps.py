from django.apps import AppConfig


class NominationsAppConfig(AppConfig):

    name = 'nominations'
