from django.apps import AppConfig


class DownloadsAppConfig(AppConfig):

    name = 'downloads'
