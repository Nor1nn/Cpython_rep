These images are linked from /community/logos/.
