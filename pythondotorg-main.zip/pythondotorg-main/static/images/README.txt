These images are from the initial Python.org content import from SVN
