import os


def get_test_rss_path():
    return os.path.join(os.path.dirname(__file__), 'psf_feed_example.xml')
