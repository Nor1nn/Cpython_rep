from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('jobs', '0013_auto_20170810_1627'),
        ('jobs', '0013_auto_20170810_1625'),
    ]

    operations = [
    ]
