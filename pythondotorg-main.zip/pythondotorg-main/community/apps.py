from django.apps import AppConfig


class CommunityAppConfig(AppConfig):

    name = 'community'
