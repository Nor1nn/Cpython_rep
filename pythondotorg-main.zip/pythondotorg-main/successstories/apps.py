from django.apps import AppConfig


class SuccessstoriesAppConfig(AppConfig):

    name = 'successstories'
