from django.apps import AppConfig


class MailingConfig(AppConfig):
    name = 'mailing'
