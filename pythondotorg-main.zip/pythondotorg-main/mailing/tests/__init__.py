"""Tests for the mailing app."""
