from django.apps import AppConfig


class CodesamplesAppConfig(AppConfig):

    name = 'codesamples'
