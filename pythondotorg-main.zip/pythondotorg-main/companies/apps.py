from django.apps import AppConfig


class CompaniesAppConfig(AppConfig):

    name = 'companies'
