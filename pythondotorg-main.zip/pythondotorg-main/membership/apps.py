from django.apps import AppConfig


class MembershipAppConfig(AppConfig):

    name = 'membership'
