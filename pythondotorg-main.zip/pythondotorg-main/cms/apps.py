from django.apps import AppConfig


class CmsAppConfig(AppConfig):

    name = 'cms'
