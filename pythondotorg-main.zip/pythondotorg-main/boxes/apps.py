from django.apps import AppConfig


class BoxesAppConfig(AppConfig):

    name = 'boxes'
