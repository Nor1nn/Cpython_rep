from django.apps import AppConfig


class SponsorsAppConfig(AppConfig):

    name = 'sponsors'
