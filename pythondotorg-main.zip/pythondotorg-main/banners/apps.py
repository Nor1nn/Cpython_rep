from django.apps import AppConfig


class BannersAppConfig(AppConfig):

    name = 'banners'
