from django.apps import AppConfig


class MinutesAppConfig(AppConfig):

    name = 'minutes'
